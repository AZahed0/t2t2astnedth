import React, { useState, useMemo } from 'react';
import { SqlOperator } from '../types';
import { CheckIcon } from './Icons';

interface ValueSelectorProps {
  operator: SqlOperator;
  uniqueValues: string[];
  selectedValues: string[];
  onSelectionChange: (values: string[]) => void;
  rangeStart: string;
  onRangeStartChange: (val: string) => void;
  rangeEnd: string;
  onRangeEndChange: (val: string) => void;
}

export const ValueSelector: React.FC<ValueSelectorProps> = React.memo(({
  operator,
  uniqueValues,
  selectedValues,
  onSelectionChange,
  rangeStart,
  onRangeStartChange,
  rangeEnd,
  onRangeEndChange,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  // Optimalisatie: Filter alleen als de operator een lijst nodig heeft
  const showList = operator === SqlOperator.IN || operator === SqlOperator.NOT_IN;

  const filteredValues = useMemo(() => {
    if (!showList) return [];
    if (!searchTerm) return uniqueValues;
    return uniqueValues.filter(v => v.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [uniqueValues, searchTerm, showList]);

  const toggleValue = (val: string) => {
    if (selectedValues.includes(val)) {
      onSelectionChange(selectedValues.filter(v => v !== val));
    } else {
      onSelectionChange([...selectedValues, val]);
    }
  };

  const selectAll = () => {
    // Selecteer alleen wat zichtbaar is in de filter
    onSelectionChange([...new Set([...selectedValues, ...filteredValues])]);
  };

  const deselectAll = () => {
    onSelectionChange([]);
  };

  // Render logic based on operator type
  if (operator === SqlOperator.IS_NULL || operator === SqlOperator.IS_NOT_NULL) {
    return (
      <div className="text-gray-500 italic p-6 bg-white rounded border border-gray-100 text-center flex flex-col items-center">
        <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-xs font-bold mb-2">Info</span>
        Geen waarden nodig voor deze operator. <br/>De query zal controleren op lege of niet-lege cellen.
      </div>
    );
  }

  if (operator === SqlOperator.BETWEEN) {
    return (
      <div className="flex flex-col sm:flex-row gap-4 bg-white p-4 rounded border border-gray-100">
        <div className="flex-1">
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Van (Minimum)</label>
          <input
            type="text"
            value={rangeStart}
            onChange={(e) => onRangeStartChange(e.target.value)}
            className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded focus:bg-white focus:ring-2 focus:ring-gisib-primary focus:border-transparent outline-none transition text-sm"
            placeholder="Bijv. 1000 of 01-01-2023"
          />
        </div>
        <div className="flex items-center justify-center text-gray-400 font-bold pt-6">-</div>
        <div className="flex-1">
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Tot (Maximum)</label>
          <input
            type="text"
            value={rangeEnd}
            onChange={(e) => onRangeEndChange(e.target.value)}
            className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded focus:bg-white focus:ring-2 focus:ring-gisib-primary focus:border-transparent outline-none transition text-sm"
            placeholder="Bijv. 2000 of 31-12-2023"
          />
        </div>
      </div>
    );
  }

  if (showList) {
    return (
      <div className="space-y-3 bg-white p-4 rounded border border-gray-100">
        <div className="flex flex-wrap justify-between items-center gap-2">
          <label className="block text-sm font-medium text-gray-700">Selecteer Waarden uit de lijst</label>
          <div className="space-x-2 text-xs">
            <button onClick={selectAll} className="text-gisib-primary hover:text-gisib-dark font-medium px-2 py-1 bg-blue-50 rounded hover:bg-blue-100 transition-colors">Alles selecteren</button>
            <span className="text-gray-300">|</span>
            <button onClick={deselectAll} className="text-red-500 hover:text-red-700 font-medium px-2 py-1 bg-red-50 rounded hover:bg-red-100 transition-colors">Alles wissen</button>
          </div>
        </div>

        <div className="relative">
            <input
            type="text"
            placeholder="Zoek in lijst..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 pl-3 border border-gray-300 rounded-md mb-2 text-sm focus:ring-1 focus:ring-gisib-primary focus:border-gisib-primary outline-none"
            />
            {searchTerm && (
                <button 
                    onClick={() => setSearchTerm('')} 
                    className="absolute right-2 top-2 text-gray-400 hover:text-gray-600"
                >
                    &times;
                </button>
            )}
        </div>

        <div className="border border-gray-200 rounded-md h-60 overflow-y-auto bg-gray-50/50 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent">
          {filteredValues.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 text-sm">
                <span>Geen waarden gevonden</span>
                {uniqueValues.length === 0 && <span className="text-xs mt-1">De geselecteerde kolom lijkt leeg.</span>}
            </div>
          ) : (
            filteredValues.map((val) => {
              const isSelected = selectedValues.includes(val);
              return (
                <div
                  key={val}
                  onClick={() => toggleValue(val)}
                  className={`flex items-center p-2.5 cursor-pointer transition border-b border-gray-100 last:border-0 hover:bg-white
                    ${isSelected ? 'bg-blue-50/80 text-gisib-dark font-medium' : 'text-gray-600'}
                  `}
                >
                  <div className={`w-4 h-4 mr-3 border rounded flex items-center justify-center transition-colors ${isSelected ? 'bg-gisib-primary border-gisib-primary' : 'border-gray-400 bg-white'}`}>
                    {isSelected && <CheckIcon />}
                  </div>
                  <span className="text-sm truncate select-none">{val}</span>
                </div>
              );
            })
          )}
        </div>
        <div className="flex justify-between text-xs text-gray-500 pt-1">
           <span>Totaal uniek: {uniqueValues.length}</span>
           <span>Geselecteerd: <span className="font-semibold text-gisib-primary">{selectedValues.length}</span></span>
        </div>
      </div>
    );
  }

  // Default for single value inputs (=, <>, >, <, LIKE)
  return (
    <div className="bg-white p-4 rounded border border-gray-100">
      <label className="block text-sm font-medium text-gray-700 mb-1">
          {operator === SqlOperator.LIKE ? 'Zoekterm (gebruik % als wildcard)' : 'Waarde'}
      </label>
      <div className="relative">
        <input
            type="text"
            value={selectedValues[0] || ''}
            onChange={(e) => onSelectionChange([e.target.value])}
            className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-gisib-primary focus:border-transparent outline-none transition font-medium text-gray-800"
            placeholder={operator === SqlOperator.LIKE ? "%school%" : "Voer waarde in..."}
        />
      </div>
      {operator === SqlOperator.LIKE && (
        <div className="mt-2 text-xs text-gray-500 bg-gray-50 p-2 rounded border border-gray-100">
            <strong>Tip:</strong> Gebruik <code>%</code> voor willekeurige tekens.<br/>
            Voorbeeld: <code>%Centrum%</code> vindt "Stadscentrum" en "Centrum-Noord".
        </div>
      )}
    </div>
  );
});