import * as XLSX from 'xlsx';
import { ExcelData } from '../types';

export const parseExcelFile = async (file: File): Promise<ExcelData> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) {
          reject(new Error("Bestand is leeg"));
          return;
        }

        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        
        if (!sheetName) {
           reject(new Error("Geen werkbladen gevonden in het bestand."));
           return;
        }

        const worksheet = workbook.Sheets[sheetName];
        
        // Use sheet_to_json with header: 1 to get raw array of arrays first to check headers
        const rawData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        
        if (rawData.length === 0) {
           reject(new Error("Werkblad is leeg."));
           return;
        }

        // Parse properly to objects
        const jsonData = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet);
        
        if (jsonData.length === 0) {
            // It might have headers but no rows
            const headers = (rawData[0] as string[]) || [];
            resolve({ headers, rows: [] });
            return;
        }

        // Get headers from the first key set of the first row (or from rawData)
        // Using Object.keys of the first row is safer for sheet_to_json result
        const headers = Object.keys(jsonData[0]);

        resolve({
          headers,
          rows: jsonData,
        });

      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};

export const getUniqueValues = (rows: Record<string, any>[], column: string): string[] => {
  const values = new Set<string>();
  rows.forEach(row => {
    const val = row[column];
    if (val !== undefined && val !== null && val !== '') {
      values.add(String(val));
    }
  });
  return Array.from(values).sort((a, b) => {
    // Try natural sort if they look like numbers
    const numA = parseFloat(a);
    const numB = parseFloat(b);
    if (!isNaN(numA) && !isNaN(numB)) {
      return numA - numB;
    }
    return a.localeCompare(b);
  });
};